import React from "https://esm.sh/react";
import { BrowserRouter as Router, Route, Routes, Link } from "https://esm.sh/react-router-dom";
import { Button } from "https://esm.sh/@/components/ui/button";
import { Card, CardContent } from "https://esm.sh/@/components/ui/card";
import { FaCcPaypal, FaCreditCard, FaMobileAlt } from "https://esm.sh/react-icons/fa";

// Home Component
const Home = () => (
  <div className="p-8 text-center">
    <h1 className="text-3xl font-bold mb-4">Welcome to MYSTIQUÉ ENTERTAINMENT</h1>
    <p className="mb-6">Choose a hotel to order from:</p>
    <div className="flex justify-center gap-6">
      <Link 
        to="/motown" 
        className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
      >
        MOTOWN
      </Link>
      <Link 
        to="/la-bona-pronto" 
        className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
      >
        La Bona Pronto
      </Link>
    </div>
  </div>
);

// Hotel Component
const Hotel = ({ name }) => (
  <div className="p-8">
    <h1 className="text-3xl font-bold mb-4">{name}</h1>
    <p className="mb-6">Explore our menu and place your order.</p>
    <Menu />
    <PaymentMethods />
  </div>
);

// Menu Component
const Menu = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    {["Burger", "Pizza", "Pasta", "Steak", "Sushi"].map((item, index) => (
      <Card key={index} className="p-4 shadow-lg bg-gray-900 text-white">
        <CardContent className="text-center">
          <h2 className="text-xl font-semibold mb-2">{item}</h2>
          <p className="text-gray-400">Delicious and freshly prepared.</p>
          <Button className="mt-4 bg-indigo-600 hover:bg-indigo-700 text-white transition">
            Order Now
          </Button>
        </CardContent>
      </Card>
    ))}
  </div>
);

// Payment Methods Component
const PaymentMethods = () => (
  <div className="mt-8 text-center">
    <h2 className="text-xl font-bold mb-4">Secure Payment Methods</h2>
    <div className="flex justify-center gap-6">
      <FaMobileAlt className="text-blue-500 text-3xl" title="M-Pesa" />
      <FaCcPaypal className="text-indigo-600 text-3xl" title="PayPal" />
      <FaCreditCard className="text-gray-700 text-3xl" title="Card Payment" />
    </div>
  </div>
);

// Main App Component
const App = () => (
  <Router>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/motown" element={<Hotel name="MOTOWN" />} />
      <Route path="/la-bona-pronto" element={<Hotel name="La Bona Pronto" />} />
    </Routes>
  </Router>
);

export default App;
